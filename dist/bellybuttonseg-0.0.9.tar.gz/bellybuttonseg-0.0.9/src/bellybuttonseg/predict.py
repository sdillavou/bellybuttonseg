from createdir import runBB

if __name__ == "__main__": 
    runBB(train=False, predict=True) 

