from createdir import createdir

if __name__ == "__main__": 
    createdir(0) 
