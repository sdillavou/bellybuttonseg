from createdir import runBB

if __name__ == "__main__": 
    runBB(train=True, predict=True) 

